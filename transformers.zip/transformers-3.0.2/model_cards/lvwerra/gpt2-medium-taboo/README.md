# GPT-2 (medium) Taboo

## What is it?
A fine-tuned GPT-2 version for Taboo cards generation.

## Training setting

The model was trained on ~900 Taboo cards in the following format for 100 epochs:
```
Describe the word Glitch without using the words Problem, Unexpected, Technology, Minor, Outage.
````

