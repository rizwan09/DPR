---
language: english
license: apache-2.0
---

## ELECTRA-small-cased

This is a cased version of `google/electra-small-discriminator`, trained on the
[OpenWebText corpus](https://skylion007.github.io/OpenWebTextCorpus/).

Uses the same tokenizer and vocab from `bert-base-cased`
